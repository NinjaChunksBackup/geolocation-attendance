import 'package:flutter/material.dart';
import 'dart:async';
import 'start_working_hour_screen.dart';
import 'setting.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Duration _duration = Duration.zero;
  bool _isWorking = false;
  Timer? _timer;

  void _startTimer() {
    setState(() {
      _isWorking = true;
      _duration = Duration.zero;
    });

    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        _duration = Duration(seconds: _duration.inSeconds + 1);
      });
    });
  }

  void _resetTimer() {
    setState(() {
      _isWorking = false;
      _duration = Duration.zero;
      _timer?.cancel();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Welcome, Employee'),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => SettingsScreen(onReset: _resetTimer)),
              );
              if (result == true) {
                _resetTimer();
              }
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          GridView.count(
            crossAxisCount: 2,
            padding: EdgeInsets.all(16.0),
            crossAxisSpacing: 16.0,
            mainAxisSpacing: 16.0,
            children: <Widget>[
              if (!_isWorking)
                _buildGridItem(Icons.access_time, 'Start Working Hour'),
              _buildGridItem(Icons.add_location_alt, 'Add New Workplace'),
              _buildGridItem(Icons.calendar_today, 'Attendance Summary'),
              _buildGridItem(Icons.assignment, 'Leave Application'),
            ],
          ),
          if (_isWorking)
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: TimerDisplay(duration: _duration, isWorking: _isWorking),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildGridItem(IconData icon, String title) {
    return Card(
      elevation: 5,
      child: InkWell(
        onTap: () async {
          if (title == 'Start Working Hour') {
            final result = await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => StartWorkingHourScreen()),
            );
            if (result == true) {
              _startTimer();
            }
          }
          // Add other navigation logic for other grid items here
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Icon(icon, size: 50, color: Colors.blueGrey),
            SizedBox(height: 10),
            Text(title,
                textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class TimerDisplay extends StatelessWidget {
  final Duration duration;
  final bool isWorking;

  TimerDisplay({required this.duration, required this.isWorking});

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 10,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
        decoration: BoxDecoration(
          color: Colors.blueGrey[800],
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          'Working: ${duration.inHours}:${(duration.inMinutes % 60).toString().padLeft(2, '0')}:${(duration.inSeconds % 60).toString().padLeft(2, '0')}',
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
      ),
    );
  }
}
