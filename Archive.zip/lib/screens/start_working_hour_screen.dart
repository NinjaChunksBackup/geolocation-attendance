import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:geolocator/geolocator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as path;
import 'dart:io';

class StartWorkingHourScreen extends StatefulWidget {
  @override
  _StartWorkingHourScreenState createState() => _StartWorkingHourScreenState();
}

class _StartWorkingHourScreenState extends State<StartWorkingHourScreen> {
  late CameraController _cameraController;
  late Future<void> _initializeControllerFuture;
  String _locationInfo = 'Detecting location...';

  final Color _primaryColor = Color(0xFF4F1787); // Purple
  final Color _accentColor = Color(0xFFEB3678); // Pink
  final Color _backgroundColor = Color(0xFF180161); // Dark Purple
  final Color _textColor = Color(0xFFFB773C); // Orange

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _detectLocation();
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
      (camera) => camera.lensDirection == CameraLensDirection.front,
    );

    _cameraController = CameraController(
      frontCamera,
      ResolutionPreset.medium,
    );

    _initializeControllerFuture = _cameraController.initialize();
  }

  Future<void> _detectLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _locationInfo =
            'Lat: ${position.latitude}, Long: ${position.longitude}, Alt: ${position.altitude}';
      });
    } catch (e) {
      setState(() {
        _locationInfo = 'Error detecting location: $e';
      });

      // Retry location detection
      Future.delayed(Duration(seconds: 3), _detectLocation);
    }
  }

  Future<void> _startWorkingHour() async {
    try {
      await _initializeControllerFuture;
      final image = await _cameraController.takePicture();

      // Save the image to a permanent directory
      final directory = await getApplicationDocumentsDirectory();
      final imagePath = path.join(directory.path, '${DateTime.now()}.png');
      await File(image.path).copy(imagePath);

      // Start the stopwatch in the HomeScreen
      Navigator.pop(context, true);
    } catch (e) {
      print('Error starting work hour: $e');
    }
  }

  @override
  void dispose() {
    _cameraController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Start Working Hour'),
        backgroundColor: _primaryColor,
      ),
      body: Container(
        color: _backgroundColor,
        child: FutureBuilder<void>(
          future: _initializeControllerFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 300,
                      width: 300,
                      decoration: BoxDecoration(
                        border: Border.all(color: _accentColor, width: 2),
                      ),
                      child: CameraPreview(_cameraController),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Align your face within the frame',
                      style: TextStyle(fontSize: 16, color: _textColor),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _startWorkingHour,
                      child: Text('Start Working Hour'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: _accentColor,
                        padding:
                            EdgeInsets.symmetric(vertical: 15, horizontal: 50),
                        textStyle: TextStyle(fontSize: 18),
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      _locationInfo,
                      style: TextStyle(fontSize: 14, color: Colors.green),
                    ),
                  ],
                ),
              );
            } else {
              return Center(child: CircularProgressIndicator());
            }
          },
        ),
      ),
    );
  }
}
