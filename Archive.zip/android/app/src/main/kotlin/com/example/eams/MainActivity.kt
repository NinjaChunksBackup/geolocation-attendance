package com.example.eams

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
